# First Homework
Assigned the 12/03/2024  
Due to a week before the first written exam  
We are required to use python, only with the numpy library (no sympy allowed)

## General
Check data

## Exercise 3
Are we sure 100% sure that we need to convert the percentages from weight to molar?

## Exercise 6
Still to Do

## Opt.
Cross-sec function  
